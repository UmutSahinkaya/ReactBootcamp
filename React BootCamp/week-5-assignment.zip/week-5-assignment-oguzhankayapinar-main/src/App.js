import Counter from "./Components/Counter";


function App() {
  return (
    <>
      <Counter/>
    </>
  );
}

export default App;
