Statefull componentler oluşturuldu.

Console.log işlemleri yapıldı.

memo ve useCallback, useMemo kullanılarak child componentlerin yeniden re-render edilmesi önlendi.

