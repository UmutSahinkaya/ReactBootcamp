export default function Header() {
  return (
    <header>
      <h1>Batuhan Yegin</h1>
    </header>
  )
}