#### Düzenleme, sayfalama, sıralama

day1 klasörü içerisindeki örneğe düzenleme, sıralama ve sayfalama işlemleri eklenecek.

#### light-dark tema

Context Api kullanılarak, react projesi oluşturulacak ve basit bir light-dark tema örneği yapılacak.

#### custom event

Javascript ile custom event örneği yapılacak ve açıklanacak.