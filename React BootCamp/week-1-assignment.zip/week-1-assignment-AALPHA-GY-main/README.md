## week-1-assignment

Cookie ve Session Storage ile set ve get işlemleri nasıl yapılır ? 

script.js dosyası içerisinde örneklerle açıklayınız.