https://mui.com/
https://styled-components.com/
https://www.figma.com/


- ana sayfa
- album detay
- login
- favoriler
- 404
- checkout
- fiyatlar