import { ListItemText, styled } from "@mui/material";

export const StyledListItemText = styled(ListItemText)`
	margin-left: 20px;
`;
