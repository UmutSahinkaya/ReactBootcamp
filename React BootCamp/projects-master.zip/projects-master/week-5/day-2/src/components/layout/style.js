import { styled, Typography } from "@mui/material";

export const FavoritesButton = styled(Typography)`
  cursor: pointer;
`