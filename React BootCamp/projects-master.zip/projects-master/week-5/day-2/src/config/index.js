export const config = {
  applicationName: "Fotoğraf Galeri Uygulaması",
  applicationTitle: "Sizin İçin Harika Fotoğraflar Listeliyoruz"
}