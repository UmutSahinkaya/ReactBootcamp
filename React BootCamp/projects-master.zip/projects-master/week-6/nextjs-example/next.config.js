module.exports = {
  reactStrictMode: false,
};
