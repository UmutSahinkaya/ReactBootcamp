import React from "react";

class Me extends React.Component {
	state = {};
	render() {
		return <div>React Bootcamp</div>;
	}
}

export default Me;
