export default function Header() {
  return (
    <header>
      <h1>Başlık</h1>
    </header>
  )
}