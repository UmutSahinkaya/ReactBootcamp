import React from "react";

export default function SurveyAnswerPage() {
  return (
    <div>Anket</div>
  )
}