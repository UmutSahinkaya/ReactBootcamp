import React from "react";

export default function ProductDetailPage() {
  return (
    <div>ProductDetailPage</div>
  )
}