import React from "react";

export default function CategoryListPage() {
  return (
    <div>CategoryListPage</div>
  )
}