import React from "react";
import HomePage from "./pages/home";

export default function App() {
  return <HomePage />
}